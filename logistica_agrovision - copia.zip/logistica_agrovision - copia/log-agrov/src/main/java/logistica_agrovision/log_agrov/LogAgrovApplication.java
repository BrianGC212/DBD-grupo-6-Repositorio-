package logistica_agrovision.log_agrov;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogAgrovApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogAgrovApplication.class, args);
	}

}
