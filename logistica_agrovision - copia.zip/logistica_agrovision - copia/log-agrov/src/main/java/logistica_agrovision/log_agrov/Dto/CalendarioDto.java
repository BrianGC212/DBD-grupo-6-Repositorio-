package logistica_agrovision.log_agrov.Dto;

public class CalendarioDto {

    private String fecha;

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
}
